AnimalCross / Little Island - sprite reference
==============================================
Everything here is what the game uses right now. Start with contact_sheets/ for a quick look; every image there is
scaled up (nearest neighbour) and labelled. All real sprites are native pixel size (the game draws them at 2x or more).

characters/            painted (AI generated, then converted by tools/*.py)
  body.png             96x320   walk cycle. Cell = 24x40, 4 frames across, 8 directions down:
                       down, down-left, left, up-left, up, up-right, right, down-right. Feet on the bottom row.
                       Hair/top/pants.png: the old clothing layers (same grid). They are switched off in the game at the moment.
  act_gather.png       192x576  action sheets. Cell = 48x48, 8 frames across, 12 rows = 3 animations x 4 directions
  act_net.png          (down, left, right, up). Feet centre is always at pixel (24, 46) in each cell.
  act_fish.png         gather: dig/crouch, hold-up (shell), reach.   net: idle+swing, catch (butterfly), lunge.
  act_emote.png        fish: cast + wait, reel (bent rod), catch.    emote: wave, hold-up (apple), extra emote.
  act_sheets.json      layout info.
tiles/
  fills.png            painted tile fills (grass, sand, water... interiors).
  atlas_day.png        the generated 'dual grid' autotile atlas (16px tiles, 36 columns x 7 rows): rows = deep water, shallow,
  atlas_cave.png       sand, grass, dirt, cobble, pond; edges are drawn by code (see js/tiles.js). Cave = recoloured day atlas.
props/
  props.png/json       painted prop sheet and the rects for each prop; individual/ holds each prop cropped out (trees, bushes,
                       rocks, flowers, lamp, bench, log, lily pads, etc).
sprites_code/          every sprite built at runtime (SPR.*): all objects as the game actually draws them, including the painted
                       props after processing (apple/orange/pear/plum trees with fruit, bushes with and without berries, shops,
                       fountain, tents, campfire, portals, crystals, signs, notes...). meta.json has sizes and anchors (ax, ay =
                       the point that sits on the object's ground position).
items/                 16x16 item icons by category (fish, bug, forage, beach) - drawn in code (js/art.js: itemIcon).
ui_icons/              16x16 button / menu icons (rod, tree, bush, bug, beach, coin, gem, shop, ...) - drawn in code (actIcon).

Not in here (made in code, no image files):
  - Decking (piers / bridges): 16px tiles, planks + beams + rails + pilings drawn by drawDeck in js/world.js.
    Styles: Driftwood a #a8723d b #b27c46 | Dark oak a #6e4a30 b #7a5238 | Pale stone a #c9b890 b #d2c29c
  - Water streaks, lily animation, leaves, clouds, rain, fireflies, vignette, lighting (js/fx.js).
  - Character skin tint: the body is recoloured per skin tone by brightness (js/assets.js, rampFn).
  - Fishing line + bobber, the minigame pop-ups (DOM/CSS, js/mini.js and style.css).
Colour palette notes: warm autumn greens/oranges, 1px dark outlines on code-drawn sprites, painted props have soft shading and
no hard outline.
